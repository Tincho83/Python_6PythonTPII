# TP II de Python para CoderHouse

## Descripción
Proyecto en Python que modela clientes de una pagina de compras, con registro de cliestes, usuarios, inicio de sesión y simulación de compras.

## Instalacion del paquete
###Instalar paquete:
* Ingresar a la carpeta donde se encuentra el paquete .tar.gz, en cmd ingresar:
* cd dist
* Luego tambien en cmd, ingresar el comando:
* pip3 install nombre_archivo_paq.tar.gz
###Se instalara en:
C:\Users\"UserName"\AppData\Local\pip\cache\wheels\CodigoAleatorio\CodigoAleatorio\CodigoAleatorio\IdCodigo
